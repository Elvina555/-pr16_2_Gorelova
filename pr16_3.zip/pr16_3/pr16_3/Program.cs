﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace pr16_3
{
    class Program
    {
        static void Main(string[] args)
        {
            if (File.Exists("file.txt"))
            {
                try
                {
                    string[] file = File.ReadAllText("file.txt").Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);
                    double[] num = file.Select(double.Parse).ToArray();
                    var chastota = num.GroupBy(a => a).Select(b => new { namb = b.Key, p = b.Count() });
                    Console.WriteLine("Число\tЧастота");
                    foreach (var chas in chastota)
                    {
                        Console.WriteLine($"{chas.namb}\t{chas.p}");
                    }
                    var mass = num.Select(a => a * chastota.First(x => x.namb == a).p).ToArray().GroupBy(a => a).Select(v => new { numb = v.Key, p = v.Count() });
                    if (File.Exists("file1.txt"))
                    {
                        File.WriteAllLines("file1.txt", mass.Select(x => x.ToString()));
                    }
                    else Console.WriteLine("Файл не найден");
                    Console.WriteLine("-------------------------");
                    foreach (var now in mass)
                    {
                        Console.WriteLine($"{now.numb}-{now.p}");
                    }
                }
                catch
                {
                    Console.WriteLine("В файле данные введены не корректно");
                }
            }
            else Console.WriteLine("Файл не найден");
            Console.ReadKey();
        }
    }
}
